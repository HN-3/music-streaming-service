package hhh.hestagram.Content;

import org.springframework.stereotype.Controller;

@Controller
public class ContentController {


}
