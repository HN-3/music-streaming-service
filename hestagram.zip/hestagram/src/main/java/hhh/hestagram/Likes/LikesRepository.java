package hhh.hestagram.Likes;

public interface LikesRepository {
}
