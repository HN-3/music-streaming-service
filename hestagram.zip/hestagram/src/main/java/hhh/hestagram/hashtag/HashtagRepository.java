package hhh.hestagram.hashtag;

public interface HashtagRepository {

}
